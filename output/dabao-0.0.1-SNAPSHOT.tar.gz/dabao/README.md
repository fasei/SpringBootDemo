# SpringBootDemo

1. 登录功能
1. 授权功能
2. 文件上传功能（图片存储本地）2018年10月23日 18:56:46
3. 文件访问（待加入）
3. ~~增加nacos服务管理器 https://nacos.io/zh-cn/docs/what-is-nacos.html~~
3. 插件化assembly打包，自动修改jar包的配置文件等
